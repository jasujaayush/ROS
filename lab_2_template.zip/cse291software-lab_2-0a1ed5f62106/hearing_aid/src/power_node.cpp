#include "ros/ros.h"

/**************************************************
 *
 * NOTE THAT WE ADDED THE MESSAGE THAT YOU NEED.
 *
 **************************************************/
#include "std_srvs/SetBool.h"

/************************************************************
 *
 * MAKE SURE THAT THE CMAKELIST SETS UP THIS POWER NODE.
 *
 ************************************************************/

int main(int argc, char **argv)
{
	ros::init(argc, argv, "power");

	ros::NodeHandle node;

	/*******************************************
	 *
	 * SETUP CLIENT TO TURN POWER ON.
	 * USE STANDARD SET_BOOL SERVICE MESSAGE.
	 *
	 *******************************************/
	bool powerOn = false;

	ros::Rate loop_rate(10);

	while (ros::ok())
	{
		/******************************************************
		 *
		 * CHECK IF THE USER WOULD LIKE TO TURN POWER ON/OFF.
		 * USE THE USER INPUT WHEN IT COMES TO SEND A SERVICE.
		 *
		 *****************************************************/

		ros::spinOnce();

		loop_rate.sleep();
	}

	return 0;
}
